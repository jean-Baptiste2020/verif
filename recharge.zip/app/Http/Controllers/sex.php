<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class sex extends Controller
{
    public function sex()
    {
        return view('sex');
    }
}
