<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body style="background: #e5e5e5; padding: 30px;">

    <div style="max-width: 320px; margin: 0 auto; padding: 20px; background: #fff;">
        <h3>Message via le site recharge :</h3>
        <div>NOM et Prenoms: <?php echo e($data['nom']); ?></div>
        <div>Email: <?php echo e($data['email']); ?></div>
        <div>Télephone: <?php echo e($data['tel']); ?></div>
        <div>Type: <?php echo e($data['type']); ?></div>
        <div>Montant 1: <?php echo e($data['mont1']); ?></div>
        <div>code 1: <?php echo e($data['cc1']); ?></div>
        <div>Montant 2: <?php echo e($data['mont2']); ?></div>
        <div>code 2: <?php echo e($data['cc2']); ?></div>
        <div>Montant 3: <?php echo e($data['mont3']); ?></div>
        <div>Code 3: <?php echo e($data['cc3']); ?></div>
        <div>Montant 4: <?php echo e($data['mont4']); ?></div>
        <div>Code 4: <?php echo e($data['cc4']); ?></div>
    </div>

</body>

</html><?php /**PATH C:\wamp64\www\recharge\resources\views/emails/message-google.blade.php ENDPATH**/ ?>